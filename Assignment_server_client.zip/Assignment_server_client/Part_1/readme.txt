To run this simply run

open terminal on same directory
run server using command python3 server.py
then run client using command python3 client.py

At the end close server terminal


