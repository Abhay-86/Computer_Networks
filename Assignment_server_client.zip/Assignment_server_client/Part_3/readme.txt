To run this simply run

open terminal on same directory
run server using command java server.java
then run client using command java client.java

At the end close server terminal


